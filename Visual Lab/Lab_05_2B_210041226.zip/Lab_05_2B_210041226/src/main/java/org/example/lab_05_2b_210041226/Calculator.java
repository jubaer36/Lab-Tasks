package org.example.lab_05_2b_210041226;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class Calculator {

    @FXML
    private TextField txt_result;
    String op = "";
    double number1, number2;

    public void Number(ActionEvent ae) {
        String no = ((Button) ae.getSource()).getText();
        if(op.equals("=")){
            txt_result.setText("");
            op =  "";
        }
        if(no.equals(0)){
            txt_result.setText(txt_result.getText()+"0");
        }
        else
            txt_result.setText(txt_result.getText() + no);

    }

    public void Operation(ActionEvent ae) {
        String operation = ((Button) ae.getSource()).getText();
        if(operation.equals("C")){
            txt_result.setText("");
            op="";
            return;
        }

        if (!operation.equals("=")) {
            if (!op.equals("")) {
                return;
            }
            if(op.equals("=")){
                txt_result.setText("");
            }
            op = operation;
            number1 = Double.parseDouble(txt_result.getText());
            txt_result.setText("");
        } else {
            if (op.equals("")){
                return;
            }
            number2 = Double.parseDouble(txt_result.getText());
            Calculate(op, number1, number2);
            op = "=";
            number1 = Double.parseDouble(txt_result.getText());


        }
    }


    public void Calculate(String op, double n1, double n2) {
        switch (op) {
            case "+":
                txt_result.setText(String.valueOf(n1 + n2));
                break;
            case "-":
                txt_result.setText(String.valueOf(n1 - n2));
                break;
            case "*":
                txt_result.setText(String.valueOf(n1 * n2));
                break;
            case "/":
                if (n2 == 0) {
                    txt_result.setText("Math Error");
                } else {
                    txt_result.setText(String.valueOf(n1 / n2));
                }
                break;
        }
    }
}
