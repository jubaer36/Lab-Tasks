module org.example.lab_05_2b_210041226 {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.example.lab_05_2b_210041226 to javafx.fxml;
    exports org.example.lab_05_2b_210041226;
}