#ifndef _KERN_THREAD_PCURID_H_
#define _KERN_THREAD_PCURID_H_

#ifdef _KERN_

unsigned int get_curid(void);
void set_curid(unsigned int curid);

#endif  /* _KERN_ */

#endif  /* !_KERN_THREAD_PCURID_H_ */
