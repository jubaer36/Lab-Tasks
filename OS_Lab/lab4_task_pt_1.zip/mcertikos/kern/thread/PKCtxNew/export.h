#ifndef _KERN_THREAD_PKCTXNEW_H_
#define _KERN_THREAD_PKCTXNEW_H_

#ifdef _KERN_

unsigned int kctx_new(void *entry, unsigned int id, unsigned int quota);

#endif  /* _KERN_ */

#endif  /* !_KERN_THREAD_PKCTXNEW_H_ */
