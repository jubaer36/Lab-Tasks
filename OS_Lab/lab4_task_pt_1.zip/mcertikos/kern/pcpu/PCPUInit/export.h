#ifndef _KERN_PCPU_PCPUINIT_H_
#define _KERN_PCPU_PCPUINIT_H_

#ifdef _KERN_

void pcpu_init(void);

#endif  /* _KERN_ */

#endif  /* !_KERN_PCPU_PCPUINIT_H_ */
